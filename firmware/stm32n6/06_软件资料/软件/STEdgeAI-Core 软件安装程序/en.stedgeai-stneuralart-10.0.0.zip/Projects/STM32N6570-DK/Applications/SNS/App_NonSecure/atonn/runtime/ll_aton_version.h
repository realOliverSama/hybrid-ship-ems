/**
 ******************************************************************************
 * @file    ll_aton_version.h
 * @author  SRA Artificial Intelligence & Embedded Architectures
 * @brief   Header file of ATON Verion information
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */

#ifndef __LL_ATON_VERSION_H
#define __LL_ATON_VERSION_H

#define LL_ATON_VERSION_NAME  "atonn-v0.4.0-909-g8e9aa4d8"
#define LL_ATON_VERSION_MAJOR (0)
#define LL_ATON_VERSION_MINOR (4)
#define LL_ATON_VERSION_MICRO (0)
#define LL_ATON_VERSION_DEV   (909)

#endif
