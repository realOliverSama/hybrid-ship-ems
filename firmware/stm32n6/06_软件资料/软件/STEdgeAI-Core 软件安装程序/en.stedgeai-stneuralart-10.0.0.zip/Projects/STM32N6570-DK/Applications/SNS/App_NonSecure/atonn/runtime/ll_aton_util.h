/**
 ******************************************************************************
 * @file    ll_aton_util.h
 * @author  SRA Artificial Intelligence & Embedded Architectures
 * @brief   Header file of ATON utility functions
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */

#ifndef __LL_ATON_UTIL_H
#define __LL_ATON_UTIL_H

#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>

#define __clean_errno() (errno == 0 ? "None" : strerror(errno))
#define __log_error(M, ...)                                                                                            \
  printf("[ERROR] (%s:%d: errno: %s) " M "\n", __FILE__, __LINE__, __clean_errno(), ##__VA_ARGS__)

/*!
   \brief Cheks a condition: if it evaluates to false, prints an error message and asserts(false).
   \param COND the condition to check.
   \param MSG the message to print if the condition evaluates to false (can be a formatted string as well)
   \param ASSERT_COND boolean parameter: if 1, this command will assert(COND), otherwise il will assert(0)
   \param variadic_args the (potential) vaariables to print in the message's formatted string, if any
*/
#define assertf(COND, ASSERT_COND, MSG, ...)                                                                           \
  if (!(COND))                                                                                                         \
  {                                                                                                                    \
    __log_error(MSG, ##__VA_ARGS__);                                                                                   \
    if (ASSERT_COND)                                                                                                   \
      assert(COND);                                                                                                    \
    else                                                                                                               \
      assert(0);                                                                                                       \
  }

/**
 * @brief  Helper function. Extracts bitfield from a buffer
 * @param  bits Pointer of the buffer to extract bits from
 * @param  pos Global bit position of the bitfield to extract
 * @retval nbits Number of bits to extract
 */
uint32_t LL_ATON_getbits(uint32_t *bits, unsigned int pos, int nbits);

/**
 * @brief  Helper function. Packs bitfield into a buffer
 * @param  bits Pointer of the buffer to pack bits into
 * @param  pos Global position of the bitfield to pack
 * @retval nbits Number of bits to extract
 */
void LL_ATON_setbits(uint32_t *bits, unsigned int pos, int nbits, unsigned int val);

#endif
